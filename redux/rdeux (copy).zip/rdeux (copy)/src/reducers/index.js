import changeTheNumber from "./upDown";
import { combineReducers } from "redux";

const rootReduced=combineReducers({
    changeTheNumber
})
export default rootReduced;