import React from 'react'
import { BrowserRouter,Switch,Route,Redirect } from 'react-router-dom'


function About() {
    return (
        <div>
            <h1>
                this is about page
            </h1>
        </div>
    )
}

export default About