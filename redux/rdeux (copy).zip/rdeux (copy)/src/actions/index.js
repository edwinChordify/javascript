export const incNumber = () => {
    return {
        type: "INCREMENT"
    }
}
export const decNumber = () => {
    return {
        type: "DECREMENT"
    }
}